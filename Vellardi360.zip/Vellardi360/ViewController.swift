import UIKit
import WebKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        let webView = WKWebView(frame: view.bounds)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(webView)
        if let url = URL(string: "https://storage.net-fs.com/hosting/8478276/3/") {
            webView.load(URLRequest(url: url))
        }
    }
}
