import UIKit
import WebKit
import CoreMotion

class ViewController: UIViewController, WKNavigationDelegate {

    var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Configurazione WebView
        let config = WKWebViewConfiguration()
        config.preferences.javaScriptEnabled = true
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.navigationDelegate = self
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(webView)

        // URL del tour 3DVista
        if let url = URL(string: "https://storage.net-fs.com/hosting/8478276/3/") {
            webView.load(URLRequest(url: url))
        }

        // Abilita sensori di movimento
        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
    }

    override var prefersHomeIndicatorAutoHidden: Bool {
        return true
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }
}
